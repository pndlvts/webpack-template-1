import style from "./assets/styles/main.scss";
import "./assets/icons/icons";


//*****************************************************************


//               remove comment to support pwa


// import runtime from 'serviceworker-webpack-plugin/lib/runtime';
//
// if ('serviceWorker' in navigator) {
//     const registration = runtime.register();
// }



//*****************************************************************

