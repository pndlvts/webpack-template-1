
export default class Header {
  constructor() {
  }
}
