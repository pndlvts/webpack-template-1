class HeaderData{
    text: string = 'hellow';
    data: number = 1;
}

export default HeaderData;
