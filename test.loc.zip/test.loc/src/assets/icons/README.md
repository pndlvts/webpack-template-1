Icons folder for generate svg sprite
