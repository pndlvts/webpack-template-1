// import "./icon-name.svg"
