Directory for public files. On build files copied to root directory 
